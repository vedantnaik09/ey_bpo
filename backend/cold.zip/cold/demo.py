from twilio.rest import Client

# Your Twilio credentials
account_sid = "AC794a6d3c32085192652213cd6e12073b"
auth_token = "cc943a33bcae8fe6f07cc18721692075"
client = Client(account_sid, auth_token)

def send_whatsapp(to_number):
    # customer_info = get_user_info(to_number)
    # name=customer_info['Name']
    message_body = f""""Hey Vivek! 👋

To celebrate Republic Day, we’re offering a ₹500 OFF on all purchases above ₹1500! 🛍️✨

This is the perfect time to grab your favorite clothes and accessories at amazing prices. Hurry, the sale ends soon! ⏳

Visit our store or shop online now and enjoy your discount! 💃🕺

Don't miss out! 💥

Cheers,
Powerlook 👗👚"""
    message = client.messages.create(
        from_='whatsapp:+14155238886',
        body=message_body,
        to=f'whatsapp:{to_number}'
    )
    print(message.sid)
    return "success"







